extends Control

# Exporting these makes the template reusable without touching code
@export var start_scene : PackedScene
@export var settings_scene : PackedScene  # Link your settings menu here

func _on_button_start_pressed() -> void:
	if start_scene:
		get_tree().change_scene_to_packed(start_scene)
	else:
		print("Error: No start_scene assigned in the Inspector!")

func _on_button_quit_pressed() -> void:
	# This closes the application
	get_tree().quit()


func _on_button_options_pressed() -> void:
	if settings_scene:
		get_tree().change_scene_to_packed(settings_scene)
	else:
		# For now, this just lets you know the button works
		print("Settings menu coming soon...")
